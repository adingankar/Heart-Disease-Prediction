/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package heartdiseaseprediction;

import java.util.Random;

public class Population
{
    public static int ELITISM_K = 5;    
    public static int POP_SIZE = ELITISM_K;  // population size
    public static int MAX_ITER = 10;             // max number of iterations
    public static double MUTATION_RATE = 0.006;     // probability of mutation
    public static double CROSSOVER_RATE = 0.85;     // probability of crossover

    public static Random m_rand = new Random();  // random-number generator
    public static Individual[] m_population;
    public double totalFitness;
    public static final int SIZE = 8;

    public Population() {
        m_population = new Individual[POP_SIZE];

        // init population				
        for (int i = 0; i < POP_SIZE; i++) 
        {
            m_population[i] = new Individual();
            m_population[i].randGenes();
            for(int j=0;j<SIZE;j++)
            {
		//System.out.print(m_population[i].getGene(j));
            }
            //System.out.println();
        }

        // evaluate current population
        this.evaluate();
    }

    public void setPopulation(Individual[] newPop) 
    {
        // this.m_population = newPop;
        System.arraycopy(newPop, 0, this.m_population, 0, POP_SIZE);
    }

    public static Individual[] getPopulation() 
    {
        //return this.m_population;
		return m_population;
    }

    public double evaluate() 
    {
        this.totalFitness = 0.0;
        for (int i = 0; i < POP_SIZE; i++) {
            this.totalFitness += m_population[i].evaluate();
        }
        return this.totalFitness;
    }

    public Individual rouletteWheelSelection() 
    {
        double randNum = m_rand.nextDouble() * this.totalFitness;
        int idx;
        for (idx=0; idx<POP_SIZE && randNum>0; ++idx) {
            randNum -= m_population[idx].getFitnessValue();
        }
        return m_population[idx-1];
    }

    public Individual findBestIndividual() 
    {
        int idxMax = 0, idxMin = 0;
        double currentMax = 0.0;
        double currentMin = 1.0;
        double currentVal;

        for (int idx=0; idx<POP_SIZE; ++idx) {
            currentVal = m_population[idx].getFitnessValue();
            if (currentMax < currentMin) {
                currentMax = currentMin = currentVal;
                idxMax = idxMin = idx;
            }
            if (currentVal > currentMax) {
                currentMax = currentVal;
                idxMax = idx;
            }
            if (currentVal < currentMin) {
                currentMin = currentVal;
                idxMin = idx;
            }
        }

        //return m_population[idxMin];      // minimization
        return m_population[idxMax];        // maximization
    }
    
    public static String chrom(String chromo)
    {
        String chromos=chromo;        
        return chromos;
    }

    public static Individual[] crossover(Individual indiv1,Individual indiv2) 
    {
        Individual[] newIndiv = new Individual[2];
        newIndiv[0] = new Individual();
        newIndiv[1] = new Individual();

        int randPoint = m_rand.nextInt(Individual.SIZE);
        int i;
        for (i=0; i<randPoint; ++i) {
            newIndiv[0].setGene(i, indiv1.getGene(i));
            newIndiv[1].setGene(i, indiv2.getGene(i));
        }
        for (; i<Individual.SIZE; ++i) {
            newIndiv[0].setGene(i, indiv2.getGene(i));
            newIndiv[1].setGene(i, indiv1.getGene(i));
        }

        return newIndiv;
    }  
}
